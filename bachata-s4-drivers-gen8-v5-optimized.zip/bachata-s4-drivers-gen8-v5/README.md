# bachata-s4-drivers

ARM64 **glibc** Mesa Turnip Vulkan packages for [BachataS4](https://github.com/JICA98).

This repository builds and hosts driver ZIPs. It does **not** ship binaries in git — only scripts and CI. Release assets are published to GitHub Releases.

Design: [`docs/superpowers/specs/2026-07-10-glibc-turnip-drivers-design.md`](docs/superpowers/specs/2026-07-10-glibc-turnip-drivers-design.md)

## Tracked lines

| Line id | Upstream branch | Source |
|---------|-----------------|--------|
| `gen8` | `turnip/gen8` | [mesa-unified](https://github.com/whitebelyash/mesa-unified/tree/turnip/gen8) |
| `mojo-26.1` | `mojo/26.1` | [mesa-unified](https://github.com/whitebelyash/mesa-unified/tree/mojo/26.1) |
| `mojo-25.0` | `mojo/25.0` | [mesa-unified](https://github.com/whitebelyash/mesa-unified/tree/mojo/25.0) |

## Package format

Each release asset is a flat ZIP:

- `libvulkan_freedreno.so` — AArch64 ELF, glibc-linked (`libc.so.6`)
- `freedreno_icd.aarch64.json` — Vulkan ICD
- `meta.json` — includes `"abi": "linux-aarch64-glibc"`

### Naming

```
Turnip-<line>-v<N>-<shortsha>-EMULATOR.zip
```

Examples:

- `Turnip-gen8-v3-7fdde2f-EMULATOR.zip`
- `Turnip-mojo-26.1-v2-08e7443-EMULATOR.zip`

Git tags: `<line>-v<N>` (for example `gen8-v3`).

Per-line counters (`v1`, `v2`, …) increase only when that line publishes a new package. The short SHA is the mesa-unified commit. A change in `patches/` also publishes a new `vN` for the same mesa SHA (`meta.json` records `patches` and `patchesId`).

## Mesa patches

`patches/*.patch` are applied to every line after clone, before meson. Current set:

- `kgsl-zero-timeout-poll` — Vulkan `timeout=0` reads `KGSL_TIMESTAMP_RETIRED` instead of blocking on `IOCTL_KGSL_DEVICE_WAITTIMESTAMP_CTXTID`. Same hunk applies to `gen8`, `mojo-26.1`, and `mojo-25.0`.

## Local build

### Dependencies (Ubuntu/Debian)

```bash
sudo dpkg --add-architecture arm64
sudo apt-get update
sudo apt-get install -y \
  git meson ninja-build python3-mako python3-setuptools \
  glslang-tools flex bison pkg-config unzip file binutils \
  gcc-aarch64-linux-gnu g++-aarch64-linux-gnu \
  libz-dev:arm64 libexpat1-dev:arm64 \
  libx11-dev:arm64 libxcb1-dev:arm64 libx11-xcb-dev:arm64 \
  libxcb-dri3-dev:arm64 libxcb-present-dev:arm64 \
  libxcb-xfixes0-dev:arm64 libxcb-randr0-dev:arm64 \
  libxcb-shm0-dev:arm64 libxcb-sync-dev:arm64 \
  libxshmfence-dev:arm64
```

### Build one line

```bash
# Force local v1 without querying GitHub releases
FORCE_VERSION=1 FORCE=1 ./scripts/build-driver.sh mojo-26.1
FORCE_VERSION=1 FORCE=1 ./scripts/build-driver.sh gen8
FORCE_VERSION=1 FORCE=1 ./scripts/build-driver.sh mojo-25.0
```

Outputs land in `dist/` (gitignored).

### Optimized builds (optional, off by default)

| Env var | Effect |
|---------|--------|
| `ENABLE_LTO=1` | Link-time optimization (`-Db_lto=true`). Longer build, more RAM. |
| `TARGET_MARCH=armv8.2-a` | Adds `-march=...` (enables LSE atomics). Only use a value that **every** target device supports, otherwise the driver crashes with an illegal instruction. |

```bash
ENABLE_LTO=1 TARGET_MARCH=armv8.2-a FORCE_VERSION=1 FORCE=1 ./scripts/build-driver.sh gen8
```

The options used are recorded in `meta.json` as `buildOptions` (empty for a default build). In CI, use the `lto` / `march` inputs of `workflow_dispatch`.

These flags are not part of the "already released" check: change them and use `force` to publish a new `vN` for the same mesa SHA. Gains in game FPS are not guaranteed (most games are GPU-bound); benchmark against the default build on a real device before publishing.

### Validate

```bash
./scripts/validate-driver.sh dist/Turnip-mojo-26.1-v1-*.zip
./tests/run-all.sh
```

## CI

Workflow: [`.github/workflows/daily-drivers.yml`](.github/workflows/daily-drivers.yml)

| Trigger | Behavior |
|---------|----------|
| Daily `06:00` UTC | Build all tracked lines; release only if the mesa tip is new |
| `workflow_dispatch` | Manual. Input `branch`: empty/`all` = every line, or a line id / mesa branch (`gen8`, `turnip/gen8`, `mojo/26.1`, …). Optional `force`. |

```bash
# Manual examples
gh workflow run daily-drivers.yml -f branch=all
gh workflow run daily-drivers.yml -f branch=turnip/gen8
gh workflow run daily-drivers.yml -f branch=mojo-26.1 -f force=true
```

CI uses the same scripts as local builds, then creates a GitHub Release with the `-EMULATOR.zip` asset. No driver binaries are committed to the repository.

## Scripts

| Script | Role |
|--------|------|
| `scripts/build-driver.sh` | Clone tip, apply patches, cross-build, package, validate |
| `scripts/apply-mesa-patches.sh` | Apply `patches/*.patch` onto a mesa tree |
| `scripts/check-kgsl-zero-timeout.sh` | Require zero-timeout poll in `wait_timestamp_safe` |
| `scripts/package-driver.sh` | Write meta/ICD/zip |
| `scripts/validate-driver.sh` | Layout / ABI / ELF / glibc checks |
| `scripts/next-version.sh` | Next `vN` + already-released detection (SHA + patches-id) |
| `scripts/check-tip.sh` | Resolve remote tip SHA |

## License

Apache-2.0 (see `LICENSE`). Mesa itself is under MIT and other licenses from upstream.
