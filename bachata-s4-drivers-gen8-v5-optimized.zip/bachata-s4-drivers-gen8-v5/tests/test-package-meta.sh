#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
pkg="$root/scripts/package-driver.sh"
[[ -x "$pkg" ]] || { echo "package-driver.sh missing"; exit 1; }

tmpdir="$(mktemp -d)"
trap 'rm -rf "$tmpdir"' EXIT
printf 'not-an-elf' >"$tmpdir/libvulkan_freedreno.so"

out="$("$pkg" \
  --line gen8 \
  --version 4 \
  --commit 09df2ee2ba97f76d4da244bc98e843f807bfa99f \
  --branch turnip/gen8 \
  --library "$tmpdir/libvulkan_freedreno.so" \
  --driver-version "Vulkan 1.4.353" \
  --patches kgsl-zero-timeout-poll \
  --patches-id abc1234 \
  --outdir "$tmpdir/dist")"

python3 - "$out" <<'PY'
import json, sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as zf:
    meta = json.loads(zf.read("meta.json"))
assert meta["abi"] == "linux-aarch64-glibc", meta
assert meta["patches"] == ["kgsl-zero-timeout-poll"], meta
assert meta["patchesId"] == "abc1234", meta
print("package meta patches ok")
PY

out2="$("$pkg" \
  --line gen8 \
  --version 5 \
  --commit 09df2ee2ba97f76d4da244bc98e843f807bfa99f \
  --branch turnip/gen8 \
  --library "$tmpdir/libvulkan_freedreno.so" \
  --driver-version "Vulkan 1.4.353" \
  --build-opts "lto,march=armv8.2-a" \
  --outdir "$tmpdir/dist2")"

python3 - "$out" "$out2" <<'PY'
import json, sys, zipfile
def meta(path):
    with zipfile.ZipFile(path) as zf:
        return json.loads(zf.read("meta.json"))
assert meta(sys.argv[1])["buildOptions"] == [], "default build must have no build options"
assert meta(sys.argv[2])["buildOptions"] == ["lto", "march=armv8.2-a"], meta(sys.argv[2])
print("package meta buildOptions ok")
PY
