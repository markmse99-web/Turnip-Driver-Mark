#!/usr/bin/env bash
set -euo pipefail
# shellcheck source=lib.sh
source "$(cd "$(dirname "$0")" && pwd)/lib.sh"

line="${1:-}"
[[ -n "$line" ]] || die "usage: build-driver.sh <line_id>"
branch="$(line_branch "$line")"
root="$(cd "$(dirname "$0")/.." && pwd)"

require_cmd git meson ninja aarch64-linux-gnu-gcc aarch64-linux-gnu-g++ python3 unzip file readelf

work="$root/work/$line"
src="$work/mesa"
build="$work/build"
prefix="$work/prefix"
dist="$root/dist"
cross="$root/meson/aarch64-linux-gnu.ini"
mkdir -p "$work" "$dist"

log "line=$line branch=$branch"

if [[ ! -d "$src/.git" ]]; then
  git clone --depth=1 --branch "$branch" "$MESA_REPO_URL" "$src"
else
  git -C "$src" remote set-url origin "$MESA_REPO_URL"
  git -C "$src" fetch --depth=1 origin "$branch"
  git -C "$src" checkout -f FETCH_HEAD
fi
commit="$(git -C "$src" rev-parse HEAD)"
short="${commit:0:7}"
log "commit=$commit"

"$root/scripts/apply-mesa-patches.sh" "$src"
kgsl="$src/src/freedreno/vulkan/tu_knl_kgsl.cc"
[[ -f "$kgsl" ]] || die "tu_knl_kgsl.cc not found in mesa tree"
"$root/scripts/check-kgsl-zero-timeout.sh" "$kgsl"
patches_id="$(mesa_patches_id)"
patch_names="$(mesa_patch_names)"
log "patches_id=$patches_id patches=$patch_names"

# Older mesa (e.g. mojo/25.0) conflicts with glibc C11 once_flag/call_once.
# Mirror the guards present on newer mesa branches.
threads_h="$src/src/c11/threads.h"
threads_c="$src/src/c11/impl/threads_posix.c"
if [[ -f "$threads_h" ]] && ! grep -q '__once_flag_defined' "$threads_h"; then
  log "patching c11 threads for glibc once_flag compatibility"
  python3 - "$threads_h" "$threads_c" <<'PY'
from pathlib import Path
import sys

header = Path(sys.argv[1])
text = header.read_text(encoding="utf-8")
old = "typedef pthread_once_t  once_flag;\n#  define ONCE_FLAG_INIT PTHREAD_ONCE_INIT"
new = (
    "#ifndef __once_flag_defined\n"
    "typedef pthread_once_t  once_flag;\n"
    "#  define ONCE_FLAG_INIT PTHREAD_ONCE_INIT\n"
    "#endif"
)
if old in text:
    text = text.replace(old, new, 1)
    header.write_text(text, encoding="utf-8")
    print(f"patched {header}")

src = Path(sys.argv[2])
if src.is_file():
    ctext = src.read_text(encoding="utf-8")
    cold = (
        "void\n"
        "call_once(once_flag *flag, void (*func)(void))\n"
        "{\n"
        "    pthread_once(flag, func);\n"
        "}\n"
    )
    cnew = (
        "#ifndef __once_flag_defined\n"
        "void\n"
        "call_once(once_flag *flag, void (*func)(void))\n"
        "{\n"
        "    pthread_once(flag, func);\n"
        "}\n"
        "#endif\n"
    )
    if cold in ctext and "#ifndef __once_flag_defined\nvoid\ncall_once" not in ctext:
        src.write_text(ctext.replace(cold, cnew, 1), encoding="utf-8")
        print(f"patched {src}")
PY
fi

if [[ -n "${FORCE_VERSION:-}" ]]; then
  version="$FORCE_VERSION"
else
  set +e
  version="$(FORCE="${FORCE:-0}" "$root/scripts/next-version.sh" --line "$line" --sha "$commit" --patches-id "$patches_id")"
  code=$?
  set -e
  if [[ "$code" -eq 2 ]]; then
    log "already released for $line @$short — nothing to do"
    exit 0
  fi
  [[ "$code" -eq 0 ]] || die "next-version failed (exit $code)"
fi
log "version=v$version"

rm -rf "$build" "$prefix"
mkdir -p "$prefix"

# Optional performance knobs (all off by default, see README "Optimized builds").
#   ENABLE_LTO=1          link-time optimization (-Db_lto=true)
#   TARGET_MARCH=<march>  e.g. armv8.2-a (enables LSE atomics); must be supported
#                         by every device that will run the package
opt_args=()
build_opts=()
if [[ "${ENABLE_LTO:-0}" == "1" ]]; then
  opt_args+=("-Db_lto=true")
  build_opts+=("lto")
fi
if [[ -n "${TARGET_MARCH:-}" ]]; then
  [[ "$TARGET_MARCH" =~ ^[A-Za-z0-9.+_-]+$ ]] || die "invalid TARGET_MARCH: $TARGET_MARCH"
  opt_args+=("-Dc_args=-march=${TARGET_MARCH}" "-Dcpp_args=-march=${TARGET_MARCH}")
  build_opts+=("march=${TARGET_MARCH}")
fi
build_opts_csv="$(IFS=,; printf '%s' "${build_opts[*]-}")"
log "build_opts=${build_opts_csv:-none}"

dump_meson_log() {
  local logf="$build/meson-logs/meson-log.txt"
  if [[ -f "$logf" ]]; then
    log "---- meson-log.txt (tail) ----"
    tail -n 80 "$logf" >&2 || true
    log "---- end meson-log ----"
  fi
}

run_meson() {
  # shellcheck disable=SC2068
  if ! meson setup "$build" "$src" \
    --cross-file "$cross" \
    --prefix "$prefix" \
    --libdir lib \
    --buildtype release \
    "$@"; then
    dump_meson_log
    return 1
  fi
}

# Do not put static-link flags in the cross-file: they break meson feature tests.
# Apply them after a successful setup, before ninja.
xcb_static_link_args="-L/usr/lib/aarch64-linux-gnu -Wl,-Bstatic -lxcb-xfixes -Wl,-Bdynamic"

if ! run_meson \
  -Dplatforms=x11 \
  -Dgallium-drivers= \
  -Dvulkan-drivers=freedreno \
  -Dfreedreno-kmds=kgsl \
  -Degl=disabled \
  -Dgles1=disabled \
  -Dgles2=disabled \
  -Dopengl=false \
  -Dllvm=disabled \
  -Dshared-llvm=disabled \
  -Dbuild-tests=false \
  -Dxmlconfig=disabled \
  ${opt_args[@]+"${opt_args[@]}"}; then
  log "primary meson setup failed; retry with minimal platforms"
  rm -rf "$build"
  run_meson \
    -Dplatforms= \
    -Dgallium-drivers= \
    -Dvulkan-drivers=freedreno \
    -Dfreedreno-kmds=kgsl \
    -Degl=disabled \
    -Dllvm=disabled \
    -Dbuild-tests=false \
    ${opt_args[@]+"${opt_args[@]}"} \
    || die "meson setup failed for line $line"
fi

# Static-link libxcb-xfixes (missing from Bachata host rootfs) into the driver only.
meson configure "$build" \
  -Dc_link_args="$xcb_static_link_args" \
  -Dcpp_link_args="$xcb_static_link_args"

ninja -C "$build" install

lib="$(find "$prefix" -name 'libvulkan_freedreno.so' -type f | head -n1)"
[[ -n "$lib" && -f "$lib" ]] || die "libvulkan_freedreno.so not found under $prefix"

# Strip for smaller packages / match production drivers.
if command -v aarch64-linux-gnu-strip >/dev/null 2>&1; then
  aarch64-linux-gnu-strip --strip-unneeded "$lib" || true
fi

# Fail closed if we still depend on libs Bachata host does not ship.
dyn_needed="$(readelf -d "$lib" | awk '/NEEDED/ {print $5}' | tr -d '[]')"
while IFS= read -r needed; do
  [[ -n "$needed" ]] || continue
  case "$needed" in
    libz.so.1|libxcb.so.1|libX11-xcb.so.1|libxcb-randr.so.0|libxcb-shm.so.0|\
    libxcb-dri3.so.0|libxcb-present.so.0|libxcb-render.so.0|libxcb-sync.so.1|\
    libX11.so.6|libstdc++.so.6|libm.so.6|libgcc_s.so.1|libc.so.6|ld-linux-aarch64.so.1|\
    libdrm.so.2|libpthread.so.0|libdl.so.2)
      ;;
    libxcb-xfixes.so.0|libexpat.so.1)
      die "driver still dynamically needs $needed (not in Bachata host rootfs); static-link it"
      ;;
    *)
      log "warning: unexpected NEEDED $needed (verify Bachata host ships it)"
      ;;
  esac
done <<<"$dyn_needed"

driver_version="Vulkan 1.4.0"
icd_src="$(find "$prefix" -name '*freedreno*.json' -type f | head -n1 || true)"
if [[ -n "${icd_src:-}" ]]; then
  api="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1],encoding="utf-8"))["ICD"].get("api_version",""))' "$icd_src" || true)"
  [[ -n "$api" ]] && driver_version="Vulkan $api"
fi

zip_path="$("$root/scripts/package-driver.sh" \
  --line "$line" \
  --version "$version" \
  --commit "$commit" \
  --branch "$branch" \
  --library "$lib" \
  --driver-version "$driver_version" \
  --patches "$patch_names" \
  --patches-id "$patches_id" \
  --build-opts "$build_opts_csv" \
  --outdir "$dist")"

if [[ "${SKIP_VALIDATE:-0}" != "1" ]]; then
  "$root/scripts/validate-driver.sh" "$zip_path"
fi

log "built $zip_path"
printf '%s\n' "$zip_path"
